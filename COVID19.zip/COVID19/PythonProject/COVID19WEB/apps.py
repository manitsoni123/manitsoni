from django.apps import AppConfig


class Covid19WebConfig(AppConfig):
    name = 'COVID19WEB'
