from django.db import models

# Create your models here.
class State(models.Model):
	statename = models.CharField(max_length=150)
	