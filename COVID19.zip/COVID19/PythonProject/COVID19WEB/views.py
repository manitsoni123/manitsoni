from django.shortcuts import render
import requests 
from django.http import HttpResponse 
from django.shortcuts import render 
import json
from COVID19WEB.models import *
# Create your views here.
l1=[]
d1={}

def home(request):
	d2={}
	alllist=[]
	d2={}
	l2 = ["AP","AR","AS","BR","CG","GA","GJ","HR","HP","JK","JH","KA","KL","MP","MH","MN","ML","MZ","NL","OR","PB","RJ","SK","TN","TS","TR","UP","UK","WB","AN","CH","DH","DD","LD","DL","PY"]
	url = 'https://api.covid19india.org/raw_data.json'
	r = requests.get(url)
	json_data = r.json()
	todos = json.loads(r.text)
	# ctlist=["Ahmadabad","Amreli","Anand","Aravalli","Banaskantha","Bharuch","Bhavnagar","Botad","Chhota Udaipur","Dahod","Dang","Devbhoomi Dwarka","Gandhinagar","Gir Somnath","Jamnagar","Junagadh","Kheda","Kachchh","Mahisagar","Mahesana","Morbi","Narmada","Navsari","Panch Mahals","Patan","Porbandar","Rajkot","Sabarkantha","Surat","Surendranagar","Tapi","Vadodara","Valsad"]
	active=0
	deceased=0
	recover=0
	for x in l2:
		for y in todos['raw_data']:
			if y['statecode']==x and y['currentstatus']=='Hospitalized':
				active+=1
				ct=y['detectedstate']
				sc=y['statecode']
		print(active)
		for a in todos['raw_data']:
			if a['statecode']==x and a['currentstatus']=='Deceased':
				deceased+=1
		print(deceased)
		for b in todos['raw_data']:
			if b['statecode']==x and b['currentstatus']=='Recovered':
				recover+=1
		Confirmed = (active+recover+deceased)
		if ct=='':
			pass
		else:
			d2={'StateName':ct,'Confirmed':Confirmed,'Active':active,'Recovered':recover,'Deceased':deceased,'StateCode':sc}
		print(d2)
		active=0
		recover=0
		deceased=0
		ct=''
		sc=''
		res_list = [] 
		alllist.append(d2)
		for i in range(len(alllist)): 
			if alllist[i] not in alllist[i + 1:]: 
				res_list.append(alllist[i]) 
		
		print(res_list)
	totalconfirmed=0
	totalrecovered=0
	totaldeath=0
	d3={}
	als=[]
	for x in res_list:
		confirmed = x['Confirmed']
		recover = x['Recovered']
		deceased = x['Deceased']
		totalconfirmed +=confirmed
		totalrecovered+=recover
		totaldeath+=deceased
	d3={'TotalConfirmed':totalconfirmed,'TotalRecovered':totalrecovered,'TotalDeceased':totaldeath}
	als.append(d3)
	# res_list.sort()
	return render(request, 'home.html', {'data':res_list,'main':als})
def District(request):
	d2={}
	res_list=[]
	url = 'https://api.covid19india.org/raw_data.json'
	r = requests.get(url)
	json_data = r.json()
	# json_pretty = json.dumps(json_data, sort_keys=True, indent=4)
	todos = json.loads(r.text)
	stcode = request.GET.get('id')
	print(stcode)
	ctlst=[]
	for x in todos['raw_data']:
		if x['statecode']==stcode:
			ctlst.append(x['detecteddistrict'])
	ct_fainal_list = []
	#Remove duplicate from list
	for i in ctlst:
		if i not in ct_fainal_list:
			ct_fainal_list.append(i)
	print(ct_fainal_list)
	active=0
	deceased=0
	recover=0
	c=''
	ct_fainal_list.append('')
	print(ct_fainal_list)
	for x in ct_fainal_list:
		for y in todos['raw_data']:
			if y['detecteddistrict']==x and y['statecode']== stcode and y['currentstatus']=='Hospitalized':
				active+=1
				ct=y['detecteddistrict']
				# print(y)
				c=y['detectedstate']
		print(active)
		for a in todos['raw_data']:
			if a['detecteddistrict']==x and a['statecode']== stcode and a['currentstatus']=='Deceased':
				deceased+=1
		print(deceased)
		for b in todos['raw_data']:
			if b['detecteddistrict']==x and b['statecode']== stcode and b['currentstatus']=='Recovered':
				recover+=1
		Confirmed = (active+recover+deceased)
		
		if ct=='':
			pass
		else:
			d2={'CityName':ct,'Confirmed':Confirmed,'Active':active,'Recovered':recover,'Deceased':deceased}
		active=0
		recover=0
		deceased=0
		ct=''
		sc=''
		res_list.append(d2)
	a1=0
	d1=0
	r1=0
	for y in todos['raw_data']:
		if y['detecteddistrict']=='' and y['statecode']== stcode and y['currentstatus']=='Hospitalized':
			a1+=1
	print(active)
	for a in todos['raw_data']:
		if a['detecteddistrict']=='' and a['statecode']== stcode and a['currentstatus']=='Deceased':
			d1+=1
	print(deceased)
	for b in todos['raw_data']:
		if b['detecteddistrict']=='' and b['statecode']== stcode and b['currentstatus']=='Recovered':
			r1+=1
	c1=0
	print(a1,d1,r1)
	c1=(a1+c1+r1)
	d2={'CityName':'Unknown','Confirmed':c1,'Active':a1,'Recovered':r1,'Deceased':d1}
	res_list.append(d2)
	res_list1 = [] 
	for i in range(len(res_list)): 
		if res_list[i] not in res_list[i + 1:]: 
			res_list1.append(res_list[i]) 
	totalconfirmed=0
	totalrecovered=0
	totaldeath=0
	d3={}
	als=[]
	print(res_list)
	for x in res_list1:
		confirmed = x['Confirmed']
		recover = x['Recovered']
		deceased = x['Deceased']
		totalconfirmed +=confirmed
		totalrecovered+=recover
		totaldeath+=deceased
	StateName=c.upper()
	d3={'StateName':StateName,'TotalConfirmed':totalconfirmed,'TotalRecovered':totalrecovered,'TotalDeceased':totaldeath}
	als.append(d3)
	# res_list1.sort()
	print(als)
	return render(request,'district.html',{'data':res_list1,'main':als}) 
def mainData(request):
    url = 'https://api.covid19india.org/raw_data.json'
    r = requests.get(url)
    json_data = r.json()
    # json_pretty = json.dumps(json_data, sort_keys=True, indent=4)
    todos = json.loads(r.text)
    # l2 = ["AP","AR","AS","BR","CG","GA","GJ","HR","HP","JK","JH","KA","KL","MP","MH","MN","ML","MZ","NL","OR","PB","RJ","SK","TN","TS","TR","UP","UK","WB","AN","CH","DH","DD","LD","DL","PY"]
    confirmed=0
    Recovered=0
    deceased=0
    active=0
    # for st in l2
    for x in todos['raw_data']:
    	if x['statecode']=='GJ' and x['currentstatus']=='Hospitalized':
    		active+=1
    # for st in l2
    for x in todos['raw_data']:
    	if x['statecode']=='GJ' and x['currentstatus']=='Recovered':
    		Recovered+=1
    # for st in l2
    for z in todos['raw_data']:
    	if z['statecode']=='GJ' and z['currentstatus']=='Deceased':
    		deceased +=1
    confirmed = (active+deceased+Recovered)
    active = (deceased-Recovered)
    d1={'Confirmed':confirmed,'Active':active,'Recovered':Recovered,'Deceased':deceased}
    l1.append(d1)
    print(l1)
    return JsonResponse(l1)
# class  RoomList(View):
#     def  get(self, request):
#         rooms =  list(Room.objects.all().values())
#         data =  dict()
#         data['rooms'] = rooms
#         return JsonResponse(data)
